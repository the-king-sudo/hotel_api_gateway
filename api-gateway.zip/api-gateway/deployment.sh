heroku login
heroku create hotel-apigateway
heroku container:login
heroku container:push web --app hotel-apigateway
heroku container:release web --app hotel-apigateway

