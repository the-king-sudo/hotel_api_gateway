module.exports = {
  authentication_api_url: 'https://gestion-hotel-be.herokuapp.com',
  reservation_api_url: 'https://reserva-java.herokuapp.com',
};
