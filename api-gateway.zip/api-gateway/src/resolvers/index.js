const authenticationResolver = require('./authenticationResolver')
const creationRoomResolver = require('./creationRoomResolver')
const reservationResolver = require('./reservationResolver')
const lodash = require('lodash')

const resolvers = lodash.merge(authenticationResolver, creationRoomResolver, reservationResolver);
module.exports = resolvers;
