const reservationResolvers = {
  Query: {
    reservationByusername: async (_, { username }, { dataSources, userIdToken }) => {
      usernameToken = (await dataSources.authAPI.detailUser(userIdToken)).username
      if (username == usernameToken)
        return await dataSources.reservationAPI.detailReservation(username);
      else
        return null;
    },
    reservationsByusername: async (_, { username }, { dataSources, userIdToken }) => {
      usernameToken = (await dataSources.authAPI.detailUser(userIdToken)).username
      if (username == usernameToken)
        return await dataSources.reservationAPI.detailReservations(username);
      else
        return null;
    }
  },
  Mutation: {
    createReservation: async (_, {Reservation}, {dataSources}) => {
      const reserCreate = {
        username: Reservation.username,
        reserUsuarious: Reservation.reserUsuarious,
        reserHabitation: Reservation.reserHabitation,
        fetchIngress: Reservation.fetchIngress,
        fetchSaida: Reservation.fetchSaida
      }
      return await dataSources.reservationAPI.createReservation(reserCreate);
    },
    updateReservation: async (_, { reservation }, { dataSources, userIdToken }) => {
      usernameToken = (await dataSources.authAPI.detailUser(userIdToken)).username
      usernameReservation = (await dataSources.reservationAPI.detailReservation).username
      if (usernameToken == usernameReservation)
        return await dataSources.reservationAPI.updateReservation(reservation)
      else
        return null;

    },
    deleteReservation: async (_, { username }, { dataSources, userIdToken }) => {
      usernameToken = (await dataSources.authAPI.detailUser(userIdToken)).username
      usernameReservation = (await dataSources.reservationAPI.detailReservation).username
      if (usernameToken == usernameReservation)
        return await dataSources.reservationAPI.deleteReservation(reservation)
      else
        return null;

    }
  },
};
module.exports = reservationResolvers;
