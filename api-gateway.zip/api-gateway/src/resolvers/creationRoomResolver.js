const creationResolvers = {
  Query: {
    creationByCodigo: async (_, { username }, { dataSources, userIdToken }) => {
      usernameToken = (await dataSources.authenticationAPI.detailUser(userIdToken)).username
      if (username == usernameToken)
        return await dataSources.authenticationAPI.detailRoom(username);
      else
        return null;
    }
  },
  Mutation: {
    createRoom: async (_, { room }, { dataSources, userIdToken }) => {
      usernameToken = (await dataSources.authenticationAPI.detailUser(userIdToken)).username
      if (username == usernameToken){
         const createInput = {
          codigo: room.codigo,
          price: room.price,
          description: room.description}
       
        }
      return await dataSources.authenticationAPI.createRoom(createInput);
    },
    updateRoom: async (_, { username, idRoom }, { dataSources, userIdToken }) => {
      usernameToken = (await dataSources.authenticationAPI.detailUser(userIdToken)).username
      if (username == usernameToken)
        return await dataSources.authenticationAPI.updateRoom(username, idRoom);
      else
        return null;

    },
    deleteRoom: async (_, { username, idRoom }, { dataSources, userIdToken }) => {
      usernameToken = (await dataSources.authenticationAPI.detailUser(userIdToken)).username
      if (username == usernameToken)
        return await dataSources.authenticationAPI.deleteRoom(username, idRoom);
      else
        return null;
    }
  },
};
module.exports = creationResolvers;
