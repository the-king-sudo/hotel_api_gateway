const userResolvers = {
  Query: {
    userDetailByidentification: async (_, { id }, { dataSources, userIdToken }) => {
      if (id == userIdToken)
        return await dataSources.authenticationAPI.detailUser(id);
      else
        return null;
    }
  },
  Mutation: {
    signUpUser: async (_, { userInput }, { dataSources }) => {
      const authInput = {
        username: userInput.username,
        password: userInput.password,
        name: userInput.name,
        identification: userInput.identification,
        phone: userInput.phone,
        email: userInput.email
      }
      return await dataSources.authenticationAPI.createrUser(authInput);
    },
    logIn: async (_, { credentials }, { dataSources }) => {
      return await dataSources.authenticationAPI.loginUser(credentials);
    },
    refreshToken: (_, { token }, { dataSources }) =>
      dataSources.authenticationAPI.refreshToken(token),

    createUPsuperUser: async (_, { superUserInput }, { dataSources }) => {
      const authInputSp = {
        username: superUserInput.username,
        password: superUserInput.password
      }
      return await dataSources.authenticationAPI.createrSpUser(authInputSp);
    }
  }
};
module.exports = userResolvers;
