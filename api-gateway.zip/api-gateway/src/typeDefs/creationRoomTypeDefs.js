const {gql} = require('apollo-server');

const creationRoomtypes = gql`
  type RoomCreation {
    codigo:String!
    description:String!
    price:Int!
  }

  input RoomCreationInput {
    codigo:String!
    description:String!
    price:Int!
  }


    type RoomDetail {
    id:Int!  
    codigo:String!
    description:String!
    availability:String!
    price:Int!
  }

  input RoomUpdate {
    id:Int!
    description:String!
    availability:String!
    price:Int!    
  }


  extend type Query{
    creationByCodigo(codigo:String!):RoomDetail 
  }

    extend type Mutation {
    createRoom(room:RoomCreationInput!):RoomCreation
    updateRoom(room:RoomUpdate!):RoomCreation
    deleteRoom(username:String!):String!
  }
`;
module.exports = creationRoomtypes;
