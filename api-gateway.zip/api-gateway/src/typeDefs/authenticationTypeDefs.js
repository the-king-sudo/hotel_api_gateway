const { gql } = require('apollo-server');

const authTypes = gql`
  type Tokens {
    refresh:String!
    access:String
  }

  type Access {
    access:String!
  }

  type LoginUser {
    username:String!
    password:String!
  }

  input LoginUserInput {
    username:String!
    password:String!
  }

    input CreateSuperUser {
    username:String!
    password:String!
  }

  input SignUpInput {
    username:String!
    password:String!
    name:String!
    identification:Int!
    phone:Int!
    email:String!
  }

  type UserDetail {
    username:String!
    name:String!
    identification:Int!
    phone:Int!
    email:String!
  }

  type Query {
    userDetailByidentification(id:Int!):UserDetail!
  }

  type Mutation{
    signUpUser(userInput:SignUpInput):Tokens!
    createUPsuperUser(superUserInput:CreateSuperUser):Tokens!
    logIn(credentials:LoginUserInput):Tokens!
    refreshToken(token:String!):Access !
  }
`;

module.exports = authTypes;
