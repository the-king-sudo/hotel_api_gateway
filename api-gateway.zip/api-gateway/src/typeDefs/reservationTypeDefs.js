const {gql} = require('apollo-server');

const Reservationtypes = gql`
  type Reservation{
    username:String!
    reserUsuarious:String!
    reserHabitation:String!
    fetchIngress:String!
    fetchSaida:String!
  }

    input ReservationInput{
    username:String!
    reserUsuarious:String!
    reserHabitation:String!
    fetchIngress:String!
    fetchSaida:String!
  }

  input ReservationUpdate{
    reserHabitation:String!
    fetchIngress:String!
    fetchSaida:String!
  }

  extend type Query {
    reservationByusername(username:String!):Reservation
    reservationsByusername(username:String!):[Reservation]
  }

  extend type Mutation {
    createReservation(reservation:ReservationInput!):Reservation
    updateReservation(reservation:ReservationUpdate!):Reservation
    deleteReservation(username:String!):String!
  }
`;
module.exports = Reservationtypes;
