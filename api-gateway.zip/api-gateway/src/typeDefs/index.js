//call all typeDefs
const authTypes = require('./authenticationTypeDefs');
const creationRoomtypes = require('./creationRoomTypeDefs');
const Reservationtypes = require('./reservationTypeDefs');

const schemaArrays = [authTypes, creationRoomtypes, Reservationtypes];
module.exports = schemaArrays;
