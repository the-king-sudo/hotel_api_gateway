const { RESTDataSource } = require('apollo-datasource-rest');
const serverConfig = require('../server');

class ReservationAPI extends RESTDataSource {
  constructor() {
    super();
    this.baseURL = serverConfig.reservation_api_url;
  }

  async createReservation(reservation) {
    reservation = new Object(JSON.parse(JSON.stringify(reservation)));
    return await this.post('/reserva', reservation);
  }

  async detailReservation(username) {
    return await this.get(`/reserva/${username}`);
  }

  async detailReservations(usernameAdmin) {
    return await this.get('/reservaciones');
  }

  async updateReservation(reservation) {
    reservation = new Object(JSON.parse(JSON.stringify(reservation)));
    return await this.put('/reserva/update', reservation);
  }

  async deleteReservation(reservaUsername) {
    return await this.delete(`/reserva/delete/${reservaUsername}`);
  }
}
module.exports = ReservationAPI;
