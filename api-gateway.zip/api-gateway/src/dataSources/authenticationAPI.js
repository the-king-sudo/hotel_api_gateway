const { RESTDataSource } = require('apollo-datasource-rest');
const serverConfig = require('../server');

class AuthenticationAPI extends RESTDataSource {
  constructor() {
    super();
    this.baseURL = serverConfig.authentication_api_url;
  }

  async createrUser(user) {
    user = new Object(JSON.parse(JSON.stringify(user)));
    return await this.post('/user/', user);
  }

  async createrSpUser(Spuser) {
    user = new Object(JSON.parse(JSON.stringify(Spuser)));
    return await this.post('/admin/', Spuser);
  }

  async detailUser(identification) {
    return await this.get('/user/detail/');
  }

  async loginUser(credentials) {
    credentials = new Object(JSON.parse(JSON.stringify(credentials)));
    return await this.post('/login/', credentials);
  }

  async refreshToken(token) {
    token = new Object(JSON.parse(JSON.stringify(token)));
    return await this.post('/refresh/', token);
  }

  async createRoom(room) {
    room = new Object(JSON.parse(JSON.stringify(room)));
    return await this.post('/habitacion/create/', room);
  }
  async detailRoom(username) {
    return await this.get(`/user/detail/${username}/`);
  }
  async updateRoom(userAdmin, idRoom) {
    userAdmin = new Object(JSON.parse(JSON.stringify(userAdmin)));
    idRoom = new Object(JSON.parse(JSON.stringify(idRoom)));
    return await this.get(`/habitacion/update/${userAdmin}/${idRoom}`, room);
  }
  async deleteRoom(userAdmin, idRoom) {
    return await this.deleteRoom(`/habitacion/remove/${userAdmin}/${idRoom}`);
  }
}

module.exports = AuthenticationAPI;
