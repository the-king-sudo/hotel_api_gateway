const { ApolloServer } = require("apollo-server");

const typeDefs = require("./typeDefs");
const resolvers = require("./resolvers");
const authentication = require("./utils/authentication");
const authenticationAPI = require("./dataSources/authenticationAPI");
const reservationAPI = require("./dataSources/reservationAPI");

const server = new ApolloServer({
  context: authentication,
  typeDefs,
  resolvers,
  dataSources: () => ({
    authenticationAPI: new authenticationAPI(),
    reservationAPI: new reservationAPI(),
  }),
  introspection: true,
  playground: true,
});

server.listen(process.env.PORT||4000).then(({ url }) => {
  console.log(`Server ready at ${url}`);
});
